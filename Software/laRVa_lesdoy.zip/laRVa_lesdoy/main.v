//-------------------------------------------------------------------- 
// Project Workshop 1 
// Taller de Proyectos 1 
// RISC-V things: larVa2, JTAG-TAP, peripherals 
// by Jesús Arias, Jesús Hernández 
//-------------------------------------------------------------------- 
`include "system.v" 
`ifdef SIMULATION 
`else 
`include "pll.v" 
`endif 
`include "jtag_arias.v" 

// Top module. (signals assigned to actual pins in file "pines.pcf") 
module main( 
    input  CLKIN,      // Input clock from crystal oscillator 
    // UART   Consola 
    input  RXD,        // P8 
    output TXD,        // P9 
    // UART 1 GPS    
    input  RXD1,       // P49 GPS_TX 
    output TXD1,       // P52 GPS_RX 
    // UART 2 ESP32-C3 
    input  RXD2,       // P122 ESP32-C3_TX 
    output TXD2,       // P121 ESP32-C3_RX 
    // ICE SPI 
    output ICE_SCK,   
    output ICE_MOSI,  
    input  ICE_MISO,  
     
    output BME680_CS,  // BME680      Chip Select (active low) 
    output ADC_CS,     // MCP3004 ADC Chip Select (active low) 
    // LORA SPI 
    output LORA_SCK,  // P115  
    output LORA_MOSI, // P110 
    input  LORA_MISO, // P113 
     
    output LORA_CS,   // LORA (P117)  Chip Select (active low) 
    
    input  LORA_BUSY, //  
    input  LORA_DIO1, // LORA DIO1 interrupt SX1262 
    output LORA_RESET,// LORA_RESET (P119) 
    output L_RX,      // LORA RX activa entrada SX1262 
    output L_TX,      // LORA TX activa salida SX1262 
 

    // LEDS GPOUT 
    output ICE_LED1, 
    output ICE_LED2, 
    output ICE_LED3, 
    output ICE_LED4, 
    // CONTROL SENSORES GPOUT 
    output EN_5V_UP, 
    output EN_5V_M4, 
    output EN_1V4_M4,  
    output M2_ON_OFF, 

    // JTAG interface 
    input  TCK, 
    input  TMS, 
    input  TDI, 
    output TDO 
); 
 

//-- PLL: generates a 'clk' MHz master clock from a 'CLKIN' MHz input 
wire clk,pll_lock; 


`ifdef SIMULATION 
assign CLKIN = clk; 
`else 
pll 
  pll1( 
    .clock_in(CLKIN), 
    .clock_out(clk), 
    .locked(pll_lock) 
    ); 
`endi

// Instance of the system 
SYSTEM sistema(  
  .clk(icclk), .reset(icreset), 
   
  .txd (ocTXD ), .rxd (icRXD ), 
  .txd1(ocTXD1), .rxd1(icRXD1), 
  .txd2(ocTXD2), .rxd2(icRXD2),  
 

.sck0(ocICE_SCK), .mosi0(ocICE_MOSI), .miso0(icICE_MISO), 
  .bme680_cs(ocBME680_CS),.adc_cs(ocADC_CS),  
   
  .sck1(ocLORA_SCK), .mosi1(ocLORA_MOSI), .miso1(icLORA_MISO),        
  .lora_cs(ocLORA_CS), 
    
  .gpout({  ocLORA_RESET,  
            ocL_RX,   
            ocL_TX,  
            ocEN_5V_UP,  
            ocEN_5V_M4,  
            ocEN_1V4_M4,  
            ocM2_ON_OFF,   
            ocICE_LED1, 
            ocICE_LED2, 
            ocICE_LED3, 
            ocICE_LED4 
        }), // MSB to LSB 
  .gpin({   icLORA_DIO1,  
            icLORA_BUSY 
        }) // MSB to LSB 
  ); 
   
// JTAG TAP Arias --------------------------------------------------------- 
localparam BSLEN = 30; 
 
wire tdo, extest, streset, intest; 
wire [BSLEN-1:0] bsd;  
// entradas cadena boundary scan, mux entrada 
//                         CORE           PIN 
assign bsd[29] = intest ?  icclk        : clk        ; 
assign bsd[28] = intest ?  icreset      : reset      ; 
assign bsd[27] = intest ?  ocTXD        : TXD        ; 
assign bsd[26] = intest ?  icRXD        : RXD        ; 
assign bsd[25] = intest ?  ocTXD1       : TXD1       ; 
assign bsd[24] = intest ?  icRXD1       : RXD1       ; 
assign bsd[23] = intest ?  ocTXD2       : TXD2       ; 
assign bsd[22] = intest ?  icRXD2       : RXD2       ; 
assign bsd[21] = intest ?  ocICE_SCK    : ICE_SCK    ; 
assign bsd[20] = intest ?  ocICE_MOSI   : ICE_MOSI   ; 
assign bsd[19] = intest ?  icICE_MISO   : ICE_MISO   ; 
assign bsd[18] = intest ?  ocBME680_CS  : BME680_CS  ; 
assign bsd[17] = intest ?  ocADC_CS     : ADC_CS     ; 
assign bsd[16] = intest ?  ocLORA_SCK   : LORA_SCK   ; 
assign bsd[15] = intest ?  ocLORA_MOSI  : LORA_MOSI  ; 
assign bsd[14] = intest ?  icLORA_MISO  : LORA_MISO  ; 
assign bsd[13] = intest ?  ocLORA_CS    : LORA_CS    ; 
assign bsd[12] = intest ?  ocLORA_RESET : LORA_RESET ; 
assign bsd[11] = intest ?  ocL_RX       : L_RX       ; 
assign bsd[10] = intest ?  ocL_TX       : L_TX       ; 
assign bsd[ 9] = intest ?  ocEN_5V_UP   : EN_5V_UP   ; 
assign bsd[ 8] = intest ?  ocEN_5V_M4   : EN_5V_M4   ; 
assign bsd[ 7] = intest ?  ocEN_1V4_M4  : EN_1V4_M4  ; 
assign bsd[ 6] = intest ?  ocM2_ON_OFF  : M2_ON_OFF  ; 
assign bsd[ 5] = intest ?  ocICE_LED1   : ICE_LED1   ; 
assign bsd[ 4] = intest ?  ocICE_LED2   : ICE_LED2   ; 
assign bsd[ 3] = intest ?  ocICE_LED3   : ICE_LED3   ; 
assign bsd[ 2] = intest ?  ocICE_LED4   : ICE_LED4   ; 
assign bsd[ 1] = intest ?  icLORA_DIO1  : LORA_DIO1  ; 
assign bsd[ 0] = intest ?  icLORA_BUSY  : LORA_BUSY  ; 
 

// salidas cadena boundary scan 
wire [BSLEN-1:0] bsq; 
 
JTAG_TAP #(.BSLEN(BSLEN)) jtag0(  
  .reset(reset),    // activo en alta 
  .tck( TCK ),      // Reloj JTAG 
  .tms( TMS  ),     // Selección JTAG 
  .tdi( TDI  ),     // Entrada datos JTAG 
  .tdo( TDO  ),     // Salida datos JTAG 
  .extest(extest),  // salida test externo 
  .intest(intest),  // salida test interno 
  .bsr_d(bsd),      // Boundary Scan entrada 
  .bsr_q(bsq)       // Boundary Scan salida 
  );  
 
// Mux de salida 
assign TXD         = exintest ?  bsq[27]: ocTXD       ; 
assign TXD1        = exintest ?  bsq[25]: ocTXD1      ; 
assign TXD2        = exintest ?  bsq[23]: ocTXD2      ; 
assign ICE_SCK     = exintest ?  bsq[21]: ocICE_SCK   ; 
assign ICE_MOSI    = exintest ?  bsq[20]: ocICE_MOSI  ; 
assign BME680_CS   = exintest ?  bsq[18]: ocBME680_CS ; 
assign ADC_CS      = exintest ?  bsq[17]: ocADC_CS    ; 
assign LORA_SCK    = exintest ?  bsq[16]: ocLORA_SCK  ; 
assign LORA_MOSI   = exintest ?  bsq[15]: ocLORA_MOSI ; 
assign LORA_CS     = exintest ?  bsq[13]: ocLORA_CS   ; 
assign LORA_RESET  = exintest ?  bsq[12]: ocLORA_RESET; 
assign L_TX        = exintest ?  bsq[11]: ocL_TX      ; 
assign L_RX        = exintest ?  bsq[10]: ocL_RX      ;  
assign EN_5V_UP    = exintest ?  bsq[ 9]: ocEN_5V_UP  ;  
assign EN_5V_M4    = exintest ?  bsq[ 8]: ocEN_5V_M4  ;  
assign EN_1V4_M4   = exintest ?  bsq[ 7]: ocEN_1V4_M4 ;  
assign M2_ON_OFF   = exintest ?  bsq[ 6]: ocM2_ON_OFF ;  
assign ICE_LED1    = exintest ?  bsq[ 5]: ocICE_LED1  ;  
assign ICE_LED2    = exintest ?  bsq[ 4]: ocICE_LED2  ;  
assign ICE_LED3    = exintest ?  bsq[ 3]: ocICE_LED3  ;  
assign ICE_LED4    = exintest ?  bsq[ 2]: ocICE_LED4  ;  
// Mux de entrada      
assign icclk       = exintest ?  bsq[29]: clk         ; 
assign icreset     = exintest ?  bsq[28]: reset       ; 
assign icRXD       = exintest ?  bsq[26]: RXD         ; 
assign icRXD1      = exintest ?  bsq[24]: RXD1        ; 
assign icRXD2      = exintest ?  bsq[22]: RXD2        ; 
assign icICE_MISO  = exintest ?  bsq[19]: ICE_MISO    ; 
assign icLORA_MISO = exintest ?  bsq[14]: LORA_MISO   ; 
assign icLORA_DIO1 = exintest ?  bsq[ 1]: LORA_DIO1   ; 
assign icLORA_BUSY = exintest ?  bsq[ 0]: LORA_BUSY   ; 
 
reg exintest;  // extest delayed 
always @(posedge clk or posedge reset)  
    if (reset) exintest <= 0; else exintest <= extest|intest; 
 
// ------------------------------------------------------------------------   
// Automatic RESET pulse: Reset is held active for 255 cycles after PLL lock 
reg [21:0]cnt=22'h3fffff; 
wire reset=(cnt!=0); 
always @(posedge clk) cnt<= reset ? cnt-1: cnt; 

endmodule 
  


