//--------------------------------------------------------------------
// RISC-V things 
// by Jesús Arias (2022)
//--------------------------------------------------------------------
/*
	Description:
		///////////////////////////////////////////////////////////////////////////////
		//----------------------------------------------------------------------------
		//--  LaRVA RISC-V System with 16KB of Internal Memory
		//----------------------------------------------------------------------------
		// Memory Map and IO Register Details
		///////////////////////////////////////////////////////////////////////////////

		Memory map:
		-----------
		0x00000000 to 0x00003FFF   Internal RAM (with initial contents)
		0x00004000 to 0x1FFFFFFF   The same internal RAM repeated each 16KB
		0x20000000 to 0xDFFFFFFF   xxxx
		0xE0000000 to 0xE00000FF   IO registers
		0xE0000100 to 0xFFFFFFFF   The same IO registers repeated each 256B

		///////////////////////////////////////////////////////////////////////////////
		// IO Register Map (all registers accessed as 32-bit words):
		///////////////////////////////////////////////////////////////////////////////

		| Address        | WRITE                          | READ                         |
		|----------------|--------------------------------|------------------------------|
		| 0xE0000080     | UART0 TX data                  | UART0 RX data                |
		| 0xE0000084     | UART0 Baud Divider             | UART0 flags                  |
		| 0xE0000090     | UART1 TX data                  | UART1 RX data                |
		| 0xE0000094     | UART1 Baud Divider             | UART1 flags                  |
		| 0xE00000A0     | UART2 TX data                  | UART2 RX data                |
		| 0xE00000A4     | UART2 Baud Divider             | UART2 flags                  |
		|                |                                |                              |
		| 0xE0000070     | SPI0 TX data                   | SPI1 RX data                 |
		| 0xE0000074     | SPI0 Control                   | SPI1 flags                   |
		| 0xE0000078     | SPI0 Slave Select              | xxxx                         |
		| 0xE0000060     | SPI1 TX data                   | SPI1 RX data                 |
		| 0xE0000064     | SPI1 Control                   | SPI1 flags                   |
		| 0xE0000068     | SPI1 Slave Select              | xxxx                         |
		|                |                                |                              |
		| 0xE0000040     | MAX_COUNT                      | TIMER                        |
		| 0xE0000030     | GPOUT                          | GPOUT                        |
		| 0xE0000034     | GPOUT                          | GPIN                         |
		| 0xE0000020     | Interrupt Enable               | Interrupt Enable             |
		|                |                                |                              |
		| 0xE0000000     | IRQ vector 0 Trap              |                              |
		| 0xE0000004     | IRQ vector 1 Timer             |                              |
		| 0xE0000008     | IRQ vector 2 RX0               |                              |
		| 0xE000000C     | IRQ vector 3 TX0               |                              |
		| 0xE0000010     | IRQ vector 4 RX1               |                              |
		| 0xE0000014     | IRQ vector 5 TX1               |                              |
		| 0xE0000018     | IRQ vector 6 RX2               |                              |
		| 0xE000001C     | IRQ vector 7 TX2               |                              |

		///////////////////////////////////////////////////////////////////////////////
		// UART Baud Divider:
		///////////////////////////////////////////////////////////////////////////////
		// Baud = Fclk / (DIVIDER + 1), with DIVIDER >= 7

		///////////////////////////////////////////////////////////////////////////////
		// UART FLAGS: 
		// bits 31-5  | bit 4 | bit 3 | bit 2 | bit 1 | bit 0
		// xxxx       | OVE   | FE    | TEND  | THRE  | DV
		///////////////////////////////////////////////////////////////////////////////
		// DV: Data Valid (RX complete if 1. Cleared reading data register)
		// THRE: TX Holding register empty (ready to write to data register if 1)
		// TEND: TX end (holding reg and shift reg both empty if 1)
		// FE: Frame Error (Stop bit received as 0 if FE=1)
		// OVE: Overrun Error (Character received when DV was still 1)
		// (DV and THRE can request interrupts when 1)

		///////////////////////////////////////////////////////////////////////////////
		// SPI Control:
		// bits 31-14 | bits 13-8 | bits 7-0
		// xxxx       | DLEN      | DIVIDER
		///////////////////////////////////////////////////////////////////////////////
		// DLEN: Data length (8 to 32 bits)
		// DIVIDER: SCK frequency = Fclk / (2 * (DIVIDER + 1))

		///////////////////////////////////////////////////////////////////////////////
		// SPI Flags:
		// bits 31-1  | bit 0
		// xxxx       | BUSY
		///////////////////////////////////////////////////////////////////////////////
		// BUSY: SPI exchanging data when 1

		///////////////////////////////////////////////////////////////////////////////
		// SPI Slave Select:
		// bits 31-2 | bit 1  | bit 0
		// xxxx      | ss1    | ss0
		///////////////////////////////////////////////////////////////////////////////
		// ss0: Selects the SPI slave 0 when 0 (active low)
		// ss1: Selects the SPI slave 1 when 0 (active low)

		///////////////////////////////////////////////////////////////////////////////
		// MAX_COUNT:
		// Holds the maximum value of the timer counter. When the timer
		// reaches this value, it gets reset and requests an interrupt if enabled.
		// Writes to MAX_COUNT also resets the timer and its interrupt flag.

		///////////////////////////////////////////////////////////////////////////////
		// TIMER:
		// The current value of the timer (incremented each clock cycle).
		// Reads also clear the interrupt flag.

		///////////////////////////////////////////////////////////////////////////////
		// GPOUT:
		// General-purpose outputs.


		///////////////////////////////////////////////////////////////////////////////
		// General Purpose Outputs (GPOUT)
		///////////////////////////////////////////////////////////////////////////////

		#define LORA_RESET   (1<<10)    // Lora Reset Pin
		#define L_RX         (1<<9)     // Lora Receive Pin
		#define L_TX         (1<<8)     // Lora Transmit Pin
		#define EN_5V_UP     (1<<7)     // Enable 5V Up Pin
		#define EN_5V_M4     (1<<6)     // Enable 5V M4 Pin
		#define EN_1V4_M4    (1<<5)     // Enable 1.4V M4 Pin
		#define M2_ON_OFF    (1<<4)     // M2 On/Off Pin
		#define LED3         (1<<3)     // LED3 Pin
		#define LED2         (1<<2)     // LED2 Pin
		#define LED1         (1<<1)     // LED1 Pin
		#define LED0         (1<<0)     // LED0 Pin

		///////////////////////////////////////////////////////////////////////////////
		// General Purpose Inputs (GPIN)
		///////////////////////////////////////////////////////////////////////////////

		#define LORA_DIO1    (1<<1)     // Lora DIO1 Pin
		#define LORA_BUSY    (1<<0)     // Lora Busy Pin

		///////////////////////////////////////////////////////////////////////////////
		// Interrupt Enable
		///////////////////////////////////////////////////////////////////////////////
		// Bit 0: Not used
		// Bit 1: Enable TIMER interrupt if 1
		// Bit 2: Enable UART0 RX interrupt if 1
		// Bit 3: Enable UART0 TX interrupt if 1
		// Bit 4: Enable UART1 RX interrupt if 1
		// Bit 5: Enable UART1 TX interrupt if 1
		// Bit 6: Enable UART2 RX interrupt if 1
		// Bit 7: Enable UART2 TX interrupt if 1

		///////////////////////////////////////////////////////////////////////////////
		// Interrupt Vectors
		///////////////////////////////////////////////////////////////////////////////
		// Hold the addresses of the corresponding interrupt service routines

         
*/

`include "laRVa.v"
`include "uart.v"

module SYSTEM (
	input clk,		// Main clock input 25MHz
	input reset,	// Global reset (active high)

	input	rxd,	// UART
	output 	txd,
	
	input	rxd1,	// UART1
	output 	txd1,
	
	input	rxd2,	// UART2
	output 	txd2,
	
	output sck,		// SPI
	output mosi,
	input  miso,	
	output fssb	// Flash CS

);

wire		cclk;	// CPU clock
assign	cclk=clk;

///////////////////////////////////////////////////////
////////////////////////// CPU ////////////////////////
///////////////////////////////////////////////////////

wire [31:0]	ca;		// CPU Address
wire [31:0]	cdo;	// CPU Data Output
wire [3:0]	mwe;	// Memory Write Enable (4 signals, one per byte lane)
wire irq;
wire [31:2]ivector;	// Where to jump on IRQ
wire trap;			// Trap irq (to IRQ vector generator)

laRVa cpu (
		.clk     (cclk ),
		.reset   (reset),
		.addr    (ca[31:2] ),
		.wdata   (cdo  ),
		.wstrb   (mwe  ),
		.rdata   (cdi  ),
		.irq     (irq  ),
		.ivector (ivector),
		.trap    (trap)
	);

 
///////////////////////////////////////////////////////
///// Memory mapping
wire iramcs;
wire iocs;
// Internal RAM selected in lower 512MB (0-0x1FFFFFFF)
assign iramcs = (ca[31:29]==3'b000);
// IO selected in last 512MB (0xE0000000-0xFFFFFFFF)
assign iocs   = (ca[31:29]==3'b111);

// Input bus mux
reg [31:0]cdi;	// Not a register
always@*
 casex ({iocs,iramcs})
        2'b01: cdi<=mdo; 
        2'b10: cdi<=iodo;
        default: cdi<=32'hxxxxxxxx;
 endcase

///////////////////////////////////////////////////////
//////////////////// internal memory //////////////////
///////////////////////////////////////////////////////
wire [31:0]	mdo;	// Output data
ram32	 ram0 ( .clk(~cclk), .re(iramcs), .wrlanes(iramcs?mwe:4'b0000),
			.addr(ca[12:2]), .data_read(mdo), .data_write(cdo) );

//////////////////////////////////////////////////
////////////////// Peripherals ///////////////////
//////////////////////////////////////////////////
reg [31:0]tcount=0;
always @(posedge clk) tcount<=tcount+1;

wire uartcs;	// UART	at offset 0x00
wire uart1cs;	// UART1	at offset 0x08
wire uart2cs;	// UART2	at offset 0x10

wire spics;		// SPI	at offset 0x20
wire irqcs;		// IRQEN at offset 0xE0
				//		 ...
				// other at offset 0xE0
assign uartcs = iocs&(ca[7:5]==3'b000);
assign uart1cs = iocs&(ca[7:5]==3'b001);
assign uart2cs = iocs&(ca[7:5]==3'b010);
//assign spics  = iocs&(ca[7:5]==3'b001);
assign irqcs  = iocs&(ca[7:5]==3'b111);

// Peripheral output bus mux
reg [31:0]iodo;	// Not a register
always@*
 casex (ca[7:2])
	6'b000xx0: iodo<={24'hx,uart_do}; 
	6'b001xx0: iodo<={24'hx,uart_d1}; 
	6'b010xx0: iodo<={24'hx,uart_d2}; 
	6'b000xx1: iodo<={27'hx,ove,fe,tend,thre,dv};
	6'b011xxx: iodo<=tcount;
	6'b111xxx: iodo<={30'hx,irqen};
	default: iodo<=32'hxxxxxxxx;
 endcase

/////////////////////////////
// UART

wire tend,thre,dv,fe,ove; // Flags
wire [7:0] uart_do;	// RX output data
wire uwrtx;			// UART TX write
wire urd;			// UART RX read (for flag clearing)
wire uwrbaud;		// UART BGR write
// Register mapping
// Offset 0: write: TX Holding reg
// Offset 0: read strobe: Clear DV, OVE (also reads RX data buffer)
// Offset 1: write: BAUD divider
assign uwrtx   = uartcs & (~ca[2]) & mwe[0];
assign uwrbaud = uartcs & ( ca[2]) & mwe[0] & mwe[1];
assign urd     = uartcs & (~ca[2]) & (mwe==4'b0000); // Clear DV, OVE flgas

UART_CORE #(.BAUDBITS(12)) uart0 ( .clk(cclk), .txd(txd), .rxd(rxd), 
	.d(cdo[15:0]), .wrtx(uwrtx), .wrbaud(uwrbaud),. rd(urd), .q(uart_do),
	.dv(dv), .fe(fe), .ove(ove), .tend(tend), .thre(thre) );

/////////////////////////////
// UART1

wire [7:0] uart_d1;	// RX output data
wire uwrtx1;			// UART TX write
wire urd1;			// UART RX read (for flag clearing)
wire uwrbaud1;		// UART BGR write
// Register mapping
// Offset 0: write: TX Holding reg
// Offset 0: read strobe: Clear DV, OVE (also reads RX data buffer)
// Offset 1: write: BAUD divider
assign uwrtx1   = uart1cs & (~ca[2]) & mwe[0];
assign uwrbaud1 = uart1cs & ( ca[2]) & mwe[0] & mwe[1];
assign urd1     = uart1cs & (~ca[2]) & (mwe==4'b0000); // Clear DV, OVE flgas

UART_CORE #(.BAUDBITS(12)) uart1 ( .clk(cclk), .txd1(txd1), .rxd1(rxd1), 
	.d(cdo[15:0]), .wrtx(uwrtx1), .wrbaud(uwrbaud1),. rd(urd1), .q(uart_d1),
	.dv(dv), .fe(fe), .ove(ove), .tend(tend), .thre(thre) );
	
/////////////////////////////
// UART2

wire [7:0] uart_d2;	// RX output data
wire uwrtx2;			// UART TX write
wire urd2;			// UART RX read (for flag clearing)
wire uwrbaud2;		// UART BGR write
// Register mapping
// Offset 0: write: TX Holding reg
// Offset 0: read strobe: Clear DV, OVE (also reads RX data buffer)
// Offset 1: write: BAUD divider
assign uwrtx2   = uart2cs & (~ca[2]) & mwe[0];
assign uwrbaud2 = uart2cs & ( ca[2]) & mwe[0] & mwe[1];
assign urd2     = uart2cs & (~ca[2]) & (mwe==4'b0000); // Clear DV, OVE flgas

UART_CORE #(.BAUDBITS(12)) uart2 ( .clk(cclk), .txd2(txd2), .rxd2(rxd2), 
	.d(cdo[15:0]), .wrtx(uwrtx2), .wrbaud(uwrbaud2),. rd(urd2), .q(uart_d2),
	.dv(dv), .fe(fe), .ove(ove), .tend(tend), .thre(thre) );

//////////////////////////////////////////
//    Interrupt control

// IRQ enable reg
reg [1:0]irqen=0;
always @(posedge cclk or posedge reset) begin
	if (reset) irqen<=0; else
	if (irqcs & (~ca[4]) &mwe[0]) irqen<=cdo[1:0];
end

// IRQ vectors
reg [31:2]irqvect[0:8];
always @(posedge cclk) if (irqcs & ca[4] & (mwe==4'b1111)) irqvect[ca[3:2]]<=cdo[31:2];

// Enabled IRQs
wire [7:0]irqpen={irqen[1]&thre, irqen[0]&dv};	// pending IRQs

// Priority encoder
wire [2:0]vecn = trap      ? 3'b000 : (	// ECALL, EBREAK: highest priority
				 irqpen[0] ? 3'b001 : (	// UART RX
				 irqpen[1] ? 3'b010 : (	// UART TX
				 
				 irqpen[2] ? 3'b011 : (	// UART1 RX
				 irqpen[3] ? 3'b100 : (	// UART1 TX
				 
				 irqpen[4] ? 3'b101 : (	// UART2 RX
				 irqpen[5] ? 3'b110 : 	// UART2 TX
				 
				 			 3'bxxx ))))));	
assign ivector = irqvect[vecn];
assign irq = (irqpen!=0)|trap;

endmodule	// System

 

/////////////////////////////////////////////////////// 
//////////////////// internal memory //////////////////
/////////////////////////////////////////////////////// 

wire [31:0] mdo;  // memory data output

ram32 ram0 (
    .clk       (~clk),                    // Clock (inverted)
    .re        (iramcs),                  // Read enable
    .wrlanes   (iramcs ? mwe : 4'b0000),  // Write lanes (conditional on iramcs)
    .addr      (ca[13:2]),                // Address (maximum 4096 addresses)
    .data_read (mdo),                     // Data read output
    .data_write(cdo)                      // Data write input
);



////////////////////////////////////////////////////////////////////////////// 
//---------------------------------------------------------------------------- 
//-- 32-bit RAM Memory with independent byte-write lanes 
//---------------------------------------------------------------------------- 
////////////////////////////////////////////////////////////////////////////// 

module ram32 (
    input clk,                             // Clock
    input re,                              // Read enable
    input [3:0] wrlanes,                   // Write lanes (4 bits to control byte write)
    input [L2N_RAM_SIZE-1:0] addr,         // Address
    output [31:0] data_read,               // Data read output
    input [31:0] data_write                // Data write input
); 

    parameter RAM_SIZE = 4096;              // RAM size (4096 entries)
    localparam L2N_RAM_SIZE = $clog2(RAM_SIZE); // Log2 of RAM size to determine address width

    reg [31:0] ram_array [0:RAM_SIZE-1];    // RAM array of 32-bit entries
    reg [31:0] data_out;                    // Register for output data

    // Assign the output data to the data_out register
    assign data_read = data_out; 

    // Write operation: write bytes to the memory based on write lanes
    always @(posedge clk) begin
        if (wrlanes[0]) ram_array[addr][7:0]   <= data_write[7:0];     // Write lower byte
        if (wrlanes[1]) ram_array[addr][15:8]  <= data_write[15:8];    // Write second byte
        if (wrlanes[2]) ram_array[addr][23:16] <= data_write[23:16];   // Write third byte
        if (wrlanes[3]) ram_array[addr][31:24] <= data_write[31:24];   // Write upper byte
    end

    // Read operation: output data from the RAM array
    always @(posedge clk) begin
        if (re) data_out <= ram_array[addr]; // Read the data at the specified address
    end

    // Initial block to load data into memory during simulation or from a file
    initial begin
        `ifdef SIMULATION
            $readmemh("rom.hex", ram_array);   // Load data from "rom.hex" for simulation
        `else
            $readmemh("rand.hex", ram_array);  // Load data from "rand.hex" for actual hardware
        `endif
    end

endmodule


